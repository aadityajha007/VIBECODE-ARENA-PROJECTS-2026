
const installWords={
en:{install:'Install app',installHelp:'In your browser menu, choose “Install SchemeSaathi” or “Add to Home screen”.'},
hi:{install:'ऐप इंस्टॉल करें',installHelp:'ब्राउज़र मेनू में “SchemeSaathi इंस्टॉल करें” या “होम स्क्रीन पर जोड़ें” चुनें।'},
bn:{install:'অ্যাপ ইনস্টল করুন',installHelp:'ব্রাউজার মেনুতে “SchemeSaathi ইনস্টল করুন” বা “হোম স্ক্রিনে যোগ করুন” বেছে নিন।'},
mr:{install:'अॅप इन्स्टॉल करा',installHelp:'ब्राउझर मेनूमधून “SchemeSaathi इन्स्टॉल करा” किंवा “होम स्क्रीनवर जोडा” निवडा.'},
ta:{install:'செயலியை நிறுவவும்',installHelp:'உலாவி மெனுவில் “SchemeSaathi-ஐ நிறுவு” அல்லது “முகப்புத் திரையில் சேர்” என்பதைத் தேர்ந்தெடுக்கவும்.'},
te:{install:'యాప్‌ను ఇన్‌స్టాల్ చేయండి',installHelp:'బ్రౌజర్ మెనూలో “SchemeSaathi ఇన్‌స్టాల్ చేయండి” లేదా “హోమ్ స్క్రీన్‌కు జోడించండి” ఎంచుకోండి.'},
gu:{install:'ઍપ ઇન્સ્ટોલ કરો',installHelp:'બ્રાઉઝર મેનૂમાં “SchemeSaathi ઇન્સ્ટોલ કરો” અથવા “હોમ સ્ક્રીન પર ઉમેરો” પસંદ કરો.'},
kn:{install:'ಆ್ಯಪ್ ಸ್ಥಾಪಿಸಿ',installHelp:'ಬ್ರೌಸರ್ ಮೆನುವಿನಲ್ಲಿ “SchemeSaathi ಸ್ಥಾಪಿಸಿ” ಅಥವಾ “ಹೋಮ್ ಸ್ಕ್ರೀನ್‌ಗೆ ಸೇರಿಸಿ” ಆಯ್ಕೆಮಾಡಿ.'}
};
const installButton=document.getElementById('installApp');let installPrompt=null;
function updateInstallLabel(){installButton.textContent='↓ '+(installWords[currentLang]||installWords.en).install}
const priorLanguageApply=applyLanguage;applyLanguage=function(){priorLanguageApply();updateInstallLabel()};
const secureLocal=['localhost','127.0.0.1','::1'].includes(location.hostname);
const standaloneMode=()=>window.matchMedia('(display-mode: standalone)').matches||navigator.standalone===true;
if((location.protocol==='https:'||secureLocal)&&!standaloneMode())installButton.hidden=false;
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();installPrompt=event;installButton.hidden=standaloneMode();updateInstallLabel()});
window.addEventListener('appinstalled',()=>{installPrompt=null;installButton.hidden=true;toast(currentLang==='hi'?'ऐप इंस्टॉल हो गया':currentLang==='bn'?'অ্যাপ ইনস্টল হয়েছে':currentLang==='mr'?'अॅप इन्स्टॉल झाले':currentLang==='ta'?'செயலி நிறுவப்பட்டது':currentLang==='te'?'యాప్ ఇన్‌స్టాల్ అయింది':currentLang==='gu'?'ઍપ ઇન્સ્ટોલ થઈ ગઈ':'SchemeSaathi installed')});
installButton.addEventListener('click',async()=>{if(!installPrompt){toast((installWords[currentLang]||installWords.en).installHelp);return}installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;installButton.hidden=true});
if('serviceWorker'in navigator&&(location.protocol==='https:'||secureLocal)){navigator.serviceWorker.register('./service-worker.js',{scope:'./'}).catch(()=>{})}
updateInstallLabel();

