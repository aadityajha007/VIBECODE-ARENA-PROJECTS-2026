const fs=require('fs'), zlib=require('zlib');
const crcTable=new Uint32Array(256);
for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;crcTable[n]=c>>>0}
function crc32(b){let c=0xffffffff;for(const v of b)c=crcTable[(c^v)&255]^(c>>>8);return(c^0xffffffff)>>>0}
function pngChunk(type,data){const t=Buffer.from(type),len=Buffer.alloc(4);len.writeUInt32BE(data.length);const body=Buffer.concat([t,data]);const crc=Buffer.alloc(4);crc.writeUInt32BE(crc32(body));return Buffer.concat([len,body,crc])}
function makeIcon(size,path){const px=new Uint8Array(size*size*4),scale=size/512;
 const put=(x,y,color)=>{x=Math.round(x*scale);y=Math.round(y*scale);if(x<0||y<0||x>=size||y>=size)return;const i=(y*size+x)*4;px[i]=color[0];px[i+1]=color[1];px[i+2]=color[2];px[i+3]=255};
 const green=[31,112,77],white=[255,255,255],gold=[243,187,99];
 for(let y=0;y<size;y++)for(let x=0;x<size;x++)put(x/scale,y/scale,green);
 function circle(cx,cy,r,c){for(let y=cy-r;y<=cy+r;y++)for(let x=cx-r;x<=cx+r;x++)if((x-cx)**2+(y-cy)**2<=r*r)put(x,y,c)}
 function line(x1,y1,x2,y2,w,c){const minX=Math.floor(Math.min(x1,x2)-w),maxX=Math.ceil(Math.max(x1,x2)+w),minY=Math.floor(Math.min(y1,y2)-w),maxY=Math.ceil(Math.max(y1,y2)+w),dx=x2-x1,dy=y2-y1,l2=dx*dx+dy*dy;for(let y=minY;y<=maxY;y++)for(let x=minX;x<=maxX;x++){let t=Math.max(0,Math.min(1,((x-x1)*dx+(y-y1)*dy)/l2));let qx=x1+t*dx,qy=y1+t*dy;if((x-qx)**2+(y-qy)**2<=(w/2)**2)put(x,y,c)}}
 circle(365,146,38,gold);
 line(126,259,256,151,25,white);line(256,151,386,259,25,white);
 line(160,245,160,373,21,white);line(352,245,352,373,21,white);line(160,373,352,373,21,white);
 line(230,373,230,295,18,white);line(230,295,282,295,18,white);line(282,295,282,373,18,white);
 const raw=Buffer.alloc(size*(size*4+1));for(let y=0;y<size;y++){const row=y*(size*4+1);raw[row]=0;for(let x=0;x<size;x++){const p=(y*size+x)*4;raw[row+1+x*4]=px[p];raw[row+2+x*4]=px[p+1];raw[row+3+x*4]=px[p+2];raw[row+4+x*4]=px[p+3]}}
 const ihdr=Buffer.alloc(13);ihdr.writeUInt32BE(size,0);ihdr.writeUInt32BE(size,4);ihdr[8]=8;ihdr[9]=6;const out=Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),pngChunk('IHDR',ihdr),pngChunk('IDAT',zlib.deflateSync(raw)),pngChunk('IEND',Buffer.alloc(0))]);fs.writeFileSync(path,out)
}
makeIcon(192,'outputs/icon-192.png');makeIcon(512,'outputs/icon-512.png');