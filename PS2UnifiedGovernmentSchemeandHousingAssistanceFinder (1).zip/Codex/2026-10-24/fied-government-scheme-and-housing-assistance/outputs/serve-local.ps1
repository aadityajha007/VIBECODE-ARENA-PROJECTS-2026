$ErrorActionPreference = 'Stop'
$root = [System.IO.Path]::GetFullPath($PSScriptRoot)
$rootPrefix = $root.TrimEnd('\') + '\'
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 8765)

try {
    $listener.Start()
} catch {
    exit 0
}

function Send-Response($stream, [int]$status, [string]$statusText, [string]$contentType, [byte[]]$body) {
    $header = "HTTP/1.1 $status $statusText`r`nContent-Type: $contentType`r`nContent-Length: $($body.Length)`r`nCache-Control: no-cache`r`nConnection: close`r`nX-Content-Type-Options: nosniff`r`nX-SchemeSaathi: local-server`r`n`r`n"
    $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($header)
    $stream.Write($headerBytes, 0, $headerBytes.Length)
    if ($body.Length -gt 0) { $stream.Write($body, 0, $body.Length) }
}

while ($listener.Server.IsBound) {
    $client = $null
    try {
        $client = $listener.AcceptTcpClient()
        $stream = $client.GetStream()
        $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::ASCII, $false, 1024, $true)
        $requestLine = $reader.ReadLine()
        while (($line = $reader.ReadLine()) -ne $null -and $line -ne '') { }

        if ([string]::IsNullOrWhiteSpace($requestLine)) { $client.Close(); continue }
        $parts = $requestLine.Split(' ')
        if ($parts.Count -lt 2 -or $parts[0] -ne 'GET') {
            Send-Response $stream 405 'Method Not Allowed' 'text/plain; charset=utf-8' ([System.Text.Encoding]::UTF8.GetBytes('Only GET is supported.'))
            $client.Close()
            continue
        }

        $requestPath = [System.Uri]::UnescapeDataString(($parts[1] -split '\?')[0]).TrimStart('/')
        if ($requestPath -eq '__health') {
            Send-Response $stream 200 'OK' 'text/plain; charset=utf-8' ([System.Text.Encoding]::UTF8.GetBytes('SchemeSaathi is running.'))
            $client.Close()
            continue
        }
        if ($requestPath -eq '__stop') {
            Send-Response $stream 200 'OK' 'text/plain; charset=utf-8' ([System.Text.Encoding]::UTF8.GetBytes('SchemeSaathi local server stopped.'))
            $client.Close()
            break
        }
        if ([string]::IsNullOrWhiteSpace($requestPath)) { $requestPath = 'index.html' }
        $filePath = [System.IO.Path]::GetFullPath((Join-Path $root $requestPath))
        if (-not $filePath.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
            Send-Response $stream 403 'Forbidden' 'text/plain; charset=utf-8' ([System.Text.Encoding]::UTF8.GetBytes('Forbidden.'))
            $client.Close()
            continue
        }
        if (-not [System.IO.File]::Exists($filePath)) {
            Send-Response $stream 404 'Not Found' 'text/plain; charset=utf-8' ([System.Text.Encoding]::UTF8.GetBytes('Not found.'))
            $client.Close()
            continue
        }

        $contentType = switch ([System.IO.Path]::GetExtension($filePath).ToLowerInvariant()) {
            '.html' { 'text/html; charset=utf-8' }
            '.js' { 'text/javascript; charset=utf-8' }
            '.webmanifest' { 'application/manifest+json; charset=utf-8' }
            '.png' { 'image/png' }
            '.svg' { 'image/svg+xml' }
            default { 'application/octet-stream' }
        }
        $body = [System.IO.File]::ReadAllBytes($filePath)
        Send-Response $stream 200 'OK' $contentType $body
    } catch {
        # A browser may close a request while the local app is shutting down.
    } finally {
        if ($client) { $client.Close() }
    }
}

$listener.Stop()
