@echo off
powershell.exe -NoProfile -WindowStyle Hidden -Command "try { $r=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8765/__health' -TimeoutSec 2; if ($r.Headers['X-SchemeSaathi'] -eq 'local-server') { Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8765/__stop' -TimeoutSec 2 | Out-Null } } catch {}"
