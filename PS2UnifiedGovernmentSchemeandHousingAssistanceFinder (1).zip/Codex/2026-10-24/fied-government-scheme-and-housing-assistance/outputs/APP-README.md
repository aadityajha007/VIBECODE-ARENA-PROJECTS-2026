# SchemeSaathi app

SchemeSaathi is packaged as an installable Progressive Web App. It can be added to a Windows desktop or a supported phone browser, and its main screen is cached for offline use after the first visit.

## Start on Windows

1. Double-click `Start-SchemeSaathi.bat`.
2. In the opened browser page, choose **Install app**. If the button is unavailable, use the browser menu and choose **Install SchemeSaathi**.
3. Open SchemeSaathi from your Start menu or app launcher after installation.

The local server listens only on this computer. Close it with `Stop-SchemeSaathi.bat` when you are finished. An installed copy can reopen its cached screen offline; official application links still require internet access.

For installation on a phone, publish these files to an HTTPS website first. Browsers require a secure website to install a web app on a different device.

The scheme records and eligibility checks remain a prototype. Personal details, shortlists, and document selections are not sent to a server.
