"""
QueueSmart AI - Automated Unit & System Integration Tests
"""
import unittest
from app import app, engine
from models import PriorityLevel, DomainType, TokenStatus


class TestQueueSmartEngine(unittest.TestCase):
    def setUp(self):
        engine.load_domain(DomainType.HOSPITAL.value)

    def test_domain_loading(self):
        self.assertEqual(engine.current_domain, DomainType.HOSPITAL.value)
        self.assertGreater(len(engine.departments), 0)
        self.assertGreater(len(engine.counters), 0)
        self.assertGreater(len(engine.tokens), 0)

    def test_token_generation(self):
        dept_id = list(engine.departments.keys())[0]
        token = engine.generate_token(
            citizen_name="Rajesh Patel",
            phone="9988776655",
            department_id=dept_id,
            priority_level=PriorityLevel.SENIOR_SPECIAL.value,
            priority_reason="Senior citizen 68 yrs"
        )
        self.assertIsNotNone(token)
        self.assertTrue(token.token_number.startswith(engine.departments[dept_id].code_prefix))
        self.assertEqual(token.citizen_name, "Rajesh Patel")
        self.assertGreater(len(token.notifications), 0)

    def test_invalid_inputs_are_handled(self):
        dept_id = list(engine.departments.keys())[0]
        token = engine.generate_token(
            citizen_name=None,
            phone=9988776655,
            department_id=dept_id,
            priority_level="senior_special",
            priority_reason="   "
        )
        self.assertEqual(token.citizen_name, "Anonymous Citizen")
        self.assertEqual(token.phone, "9988776655")
        self.assertEqual(token.priority_level, PriorityLevel.SENIOR_SPECIAL)

        with self.assertRaises(ValueError):
            engine.add_counter("Broken Counter", "unknown_dept")

        counter_id = list(engine.counters.keys())[0]
        engine.toggle_counter_status(counter_id, is_active="false")
        self.assertFalse(engine.counters[counter_id].is_active)

    def test_call_next_and_complete(self):
        # Find an active counter
        active_counter = [c for c in engine.counters.values() if c.is_active][0]
        called_token = engine.call_next(active_counter.id)
        if called_token:
            self.assertEqual(called_token.status, TokenStatus.SERVING)
            self.assertEqual(active_counter.current_token_id, called_token.id)

            # Complete service
            completed = engine.complete_service(active_counter.id)
            self.assertEqual(completed.status, TokenStatus.COMPLETED)
            self.assertIsNone(active_counter.current_token_id)

    def test_ai_optimization_recommendations(self):
        # Create artificial surge in a department
        dept_id = list(engine.departments.keys())[0]
        for i in range(6):
            engine.generate_token(f"Surge Citizen {i}", "9800000000", dept_id)
        engine.recalculate_all_queues()
        self.assertGreater(len(engine.ai_recommendations), 0)
        rec = engine.ai_recommendations[0]
        self.assertIn("department_id", rec)

        # Apply recommendation
        res = engine.apply_ai_recommendation(rec["id"])
        self.assertTrue(res["success"])


class TestFlaskAPI(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_home_page(self):
        res = self.client.get('/')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"QueueSmart", res.data)

    def test_api_state(self):
        res = self.client.get('/api/state')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("departments", data)
        self.assertIn("counters", data)
        self.assertIn("stats", data)

    def test_api_token_generation(self):
        dept_id = list(engine.departments.keys())[0]
        payload = {
            "citizen_name": "Test User",
            "phone": "9876543210",
            "department_id": dept_id,
            "priority_level": "GENERAL"
        }
        res = self.client.post('/api/token/generate', json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data["success"])
        self.assertIn("token", data)

    def test_api_invalid_counter_add_returns_400(self):
        res = self.client.post('/api/counter/add', json={"name": "Broken Counter", "department_id": "missing_dept"})
        self.assertEqual(res.status_code, 400)
        self.assertIn("error", res.get_json())


    def test_api_advance_token(self):
        dept_id = list(engine.departments.keys())[0]
        t = engine.generate_token("Advance Test", "9876543210", dept_id)
        res = self.client.post('/api/token/advance', json={"token_id": t.id})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data["success"])

    def test_api_transfer_token(self):
        dept_ids = list(engine.departments.keys())
        t = engine.generate_token("Transfer Test", "9876543210", dept_ids[0])
        res = self.client.post('/api/token/transfer', json={"token_id": t.id, "department_id": dept_ids[1], "note": "Referred"})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data["success"])
        self.assertEqual(data["token"]["department_id"], dept_ids[1])

    def test_api_simulate_surge(self):
        dept_id = list(engine.departments.keys())[0]
        res = self.client.post('/api/sim/surge', json={"department_id": dept_id, "count": 3})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data["success"])
        self.assertEqual(data["count"], 3)


if __name__ == '__main__':
    unittest.main()
