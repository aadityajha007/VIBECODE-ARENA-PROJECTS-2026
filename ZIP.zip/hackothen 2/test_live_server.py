"""
QueueSmart AI - Live Server End-to-End HTTP Probe
"""
import urllib.request
import json

BASE_URL = "http://127.0.0.1:5000"


def post_json(endpoint, data=None):
    url = f"{BASE_URL}{endpoint}"
    payload = json.dumps(data or {}).encode('utf-8')
    req = urllib.request.Request(url, data=payload, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req) as res:
        return json.loads(res.read().decode('utf-8'))


def get_json(endpoint):
    url = f"{BASE_URL}{endpoint}"
    with urllib.request.urlopen(url) as res:
        return json.loads(res.read().decode('utf-8'))


def run_live_probe():
    print("=== LIVE SERVER PROBE STARTED ===")

    # 1. Check Root
    with urllib.request.urlopen(BASE_URL) as res:
        assert res.status == 200
        print(" [PASS] GET / returned 200 OK")

    # 2. Check State
    state = get_json('/api/state')
    assert "departments" in state and "counters" in state
    print(f" [PASS] GET /api/state returned domain: {state['domain']} with {len(state['departments'])} departments")

    # 3. Generate Token
    dept_id = state["departments"][0]["id"]
    t_res = post_json('/api/token/generate', {
        "citizen_name": "Audit Live Patient",
        "phone": "9876543210",
        "department_id": dept_id,
        "priority_level": "GENERAL"
    })
    assert t_res["success"] is True
    t = t_res["token"]
    print(f" [PASS] POST /api/token/generate created {t['token_number']} for {t['citizen_name']}")

    # 4. Advance Token (Pitch Demo Booster)
    adv_res = post_json('/api/token/advance', {"token_id": t["id"]})
    assert adv_res["success"] is True
    print(f" [PASS] POST /api/token/advance transitioned status to {adv_res['token']['status']}")

    # 5. Simulate Surge
    surge_res = post_json('/api/sim/surge', {"department_id": dept_id, "count": 4})
    assert surge_res["success"] is True
    print(f" [PASS] POST /api/sim/surge created {surge_res['count']} rush citizens")

    # 6. Check AI Recommendations
    state2 = get_json('/api/state')
    recs = state2["ai_recommendations"]
    assert len(recs) > 0
    rec_id = recs[0]["id"]
    print(f" [PASS] AI Engine identified {len(recs)} optimization recommendation(s): {recs[0]['title']}")

    # 7. Apply AI recommendation
    apply_res = post_json('/api/ai/apply', {"recommendation_id": rec_id})
    assert apply_res["success"] is True
    print(f" [PASS] POST /api/ai/apply executed: {apply_res['message']}")

    # 8. Test Sector Switching
    bank_res = post_json('/api/sim/domain', {"domain": "BANK"})
    assert bank_res["success"] is True
    print(" [PASS] POST /api/sim/domain switched successfully to BANK")

    hosp_res = post_json('/api/sim/domain', {"domain": "HOSPITAL"})
    assert hosp_res["success"] is True
    print(" [PASS] POST /api/sim/domain returned back to HOSPITAL")

    print("\n=== ALL LIVE ENDPOINTS VERIFIED 100% OPERATIONAL WITH ZERO BUGS! ===")


if __name__ == '__main__':
    run_live_probe()
