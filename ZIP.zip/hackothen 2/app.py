"""
QueueSmart AI - Flask Web Application Server
"""
import os
import json
from flask import Flask, render_template, request, jsonify
from queue_engine import QueueSmartEngine
from models import PriorityLevel, DomainType

app = Flask(__name__, template_folder="templates", static_folder="static")
engine = QueueSmartEngine(domain=DomainType.HOSPITAL.value)


@app.route("/")
def index():
    """Main application landing page with all modules."""
    return render_template("index.html")


@app.route("/api/state", methods=["GET"])
def get_state():
    """Returns current synchronized queue state."""
    engine.recalculate_all_queues()
    return jsonify(engine.get_full_state())


@app.route("/api/token/generate", methods=["POST"])
def generate_token():
    """Issues a new token for citizen registration."""
    data = request.get_json() or {}
    name = data.get("citizen_name", "Anonymous Citizen")
    phone = data.get("phone", "")
    department_id = data.get("department_id")
    priority_level = data.get("priority_level", PriorityLevel.GENERAL.value)
    priority_reason = data.get("priority_reason", "Standard registration")
    appointment_time = data.get("appointment_time")

    if not department_id:
        return jsonify({"error": "Department ID is required"}), 400

    token = engine.generate_token(
        citizen_name=name,
        phone=phone,
        department_id=department_id,
        priority_level=priority_level,
        priority_reason=priority_reason,
        appointment_time=appointment_time
    )
    return jsonify({
        "success": True,
        "token": token.to_dict(),
        "message": f"Token {token.token_number} generated successfully!"
    })


@app.route("/api/token/<token_id>", methods=["GET"])
def get_token_details(token_id):
    """Retrieves live status and simulated SMS inbox for a specific token."""
    engine.recalculate_all_queues()
    if token_id not in engine.tokens:
        return jsonify({"error": "Token not found"}), 404
    token = engine.tokens[token_id]
    return jsonify({
        "token": token.to_dict(),
        "disclaimer": "Estimated waiting time is calculated algorithmically and may change based on service variance."
    })


@app.route("/api/counter/call-next", methods=["POST"])
def counter_call_next():
    """Staff action: Calls next highest priority citizen."""
    data = request.get_json() or {}
    counter_id = data.get("counter_id")
    if not counter_id:
        return jsonify({"error": "Counter ID required"}), 400

    called_token = engine.call_next(counter_id)
    if not called_token:
        return jsonify({
            "success": False,
            "message": "No waiting citizens found for this counter at the moment."
        })

    return jsonify({
        "success": True,
        "token": called_token.to_dict(),
        "message": f"Calling Token {called_token.token_number}!"
    })


@app.route("/api/counter/complete", methods=["POST"])
def counter_complete_service():
    """Staff action: Completes consultation."""
    data = request.get_json() or {}
    counter_id = data.get("counter_id")
    if not counter_id:
        return jsonify({"error": "Counter ID required"}), 400

    completed_token = engine.complete_service(counter_id)
    if not completed_token:
        return jsonify({"success": False, "message": "No active token currently serving at this counter."})

    return jsonify({
        "success": True,
        "token": completed_token.to_dict(),
        "message": f"Service completed for {completed_token.token_number}."
    })


@app.route("/api/counter/no-show", methods=["POST"])
def counter_mark_no_show():
    """Staff action: Marks token as no show."""
    data = request.get_json() or {}
    counter_id = data.get("counter_id")
    if not counter_id:
        return jsonify({"error": "Counter ID required"}), 400

    token = engine.mark_no_show(counter_id)
    if not token:
        return jsonify({"success": False, "message": "No active token to mark as no-show."})

    return jsonify({
        "success": True,
        "token": token.to_dict(),
        "message": f"Token {token.token_number} marked as No-Show."
    })


@app.route("/api/counter/toggle", methods=["POST"])
def toggle_counter():
    """Admin action: Open/Close counter."""
    data = request.get_json() or {}
    counter_id = data.get("counter_id")
    is_active = data.get("is_active")
    if not counter_id:
        return jsonify({"error": "Counter ID required"}), 400

    try:
        counter = engine.toggle_counter_status(counter_id, is_active=is_active)
        return jsonify({
            "success": True,
            "counter": counter.__dict__,
            "message": f"{counter.name} is now {'OPEN' if counter.is_active else 'CLOSED'}."
        })
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/counter/add", methods=["POST"])
def add_counter():
    """Admin action: Add a new service counter."""
    data = request.get_json() or {}
    name = data.get("name", "New Service Counter")
    department_id = data.get("department_id")
    staff_name = data.get("staff_name", "Service Officer")

    if not department_id:
        return jsonify({"error": "Department ID is required"}), 400

    try:
        new_c = engine.add_counter(name, department_id, staff_name)
        return jsonify({
            "success": True,
            "counter": new_c.__dict__,
            "message": f"Counter {new_c.name} added successfully."
        })
    except ValueError as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/counter/reassign", methods=["POST"])
def reassign_counter():
    """Admin action: Reassign counter department."""
    data = request.get_json() or {}
    counter_id = data.get("counter_id")
    department_id = data.get("department_id")

    if not counter_id or not department_id:
        return jsonify({"error": "Counter ID and Department ID required"}), 400

    try:
        counter = engine.reassign_counter(counter_id, department_id)
        return jsonify({
            "success": True,
            "counter": counter.__dict__,
            "message": f"{counter.name} reassigned."
        })
    except ValueError as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/ai/apply", methods=["POST"])
def apply_ai():
    """Applies an AI optimization recommendation."""
    data = request.get_json() or {}
    rec_id = data.get("recommendation_id")
    if not rec_id:
        return jsonify({"error": "recommendation_id required"}), 400

    result = engine.apply_ai_recommendation(rec_id)
    return jsonify(result)


@app.route("/api/sim/citizen", methods=["POST"])
def simulate_citizen():
    """Generates a random simulated arriving citizen for live demonstration."""
    token = engine.simulate_random_citizen()
    return jsonify({
        "success": True,
        "token": token.to_dict(),
        "message": f"Simulated arrival: {token.citizen_name} ({token.token_number})"
    })


@app.route("/api/sim/domain", methods=["POST"])
def switch_domain():
    """Switches the operating sector/domain (HOSPITAL, BANK, GOVERNMENT)."""
    data = request.get_json() or {}
    domain = data.get("domain", DomainType.HOSPITAL.value).upper()
    engine.load_domain(domain)
    return jsonify({
        "success": True,
        "domain": domain,
        "message": f"Domain switched to {domain}."
    })


@app.route("/api/token/advance", methods=["POST"])
def advance_token():
    """Pitch Demo booster: Fast-forwards token through workflow."""
    data = request.get_json() or {}
    token_id = data.get("token_id")
    if not token_id:
        return jsonify({"error": "token_id required"}), 400

    token = engine.advance_token_for_demo(token_id)
    if not token:
        return jsonify({"error": "Token not found"}), 404

    return jsonify({
        "success": True,
        "token": token.to_dict(),
        "message": f"Token {token.token_number} transitioned to {token.status.value}!"
    })


@app.route("/api/token/transfer", methods=["POST"])
def transfer_token():
    """Transfers citizen to a different department."""
    data = request.get_json() or {}
    token_id = data.get("token_id")
    department_id = data.get("department_id")
    note = data.get("note", "Referred consultation")

    if not token_id or not department_id:
        return jsonify({"error": "token_id and department_id required"}), 400

    token = engine.transfer_token(token_id, department_id, note)
    if not token:
        return jsonify({"error": "Token or department not found"}), 404

    return jsonify({
        "success": True,
        "token": token.to_dict(),
        "message": f"Token {token.token_number} transferred to {token.department_name}."
    })


@app.route("/api/sim/surge", methods=["POST"])
def trigger_surge():
    """Simulates rush hour influx in a department."""
    data = request.get_json() or {}
    dept_id = data.get("department_id")
    count = int(data.get("count", 4))

    tokens = engine.simulate_surge(dept_id, count)
    return jsonify({
        "success": True,
        "count": len(tokens),
        "message": f"Simulated surge: {len(tokens)} citizens joined the queue!"
    })


@app.route("/api/sim/reset", methods=["POST"])
def reset_simulation():
    """Resets queue to fresh sample data."""
    engine.load_domain(engine.current_domain)
    return jsonify({
        "success": True,
        "message": "Queue state reset to fresh sample records."
    })


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"QueueSmart AI running on http://127.0.0.1:{port}")
    app.run(host="0.0.0.0", port=port, debug=False)
