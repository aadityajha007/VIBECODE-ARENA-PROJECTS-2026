"""
QueueSmart AI - Data Models and Schema
"""
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from typing import List, Optional, Dict, Any
import uuid


class PriorityLevel(str, Enum):
    EMERGENCY = "EMERGENCY"           # Weight: 1 (Highest priority, urgent medical/crisis)
    SENIOR_SPECIAL = "SENIOR_SPECIAL" # Weight: 2 (Senior Citizens 60+, Differently Abled, Pregnant)
    APPOINTMENT = "APPOINTMENT"       # Weight: 3 (Pre-booked appointment slot)
    GENERAL = "GENERAL"               # Weight: 4 (Regular walk-in)


class TokenStatus(str, Enum):
    WAITING = "WAITING"
    APPROACHING = "APPROACHING"   # Within top 2 in line
    SERVING = "SERVING"
    COMPLETED = "COMPLETED"
    NO_SHOW = "NO_SHOW"
    CANCELLED = "CANCELLED"


class DomainType(str, Enum):
    HOSPITAL = "HOSPITAL"
    BANK = "BANK"
    GOVERNMENT = "GOVERNMENT"


@dataclass
class Department:
    id: str
    name: str
    code_prefix: str
    avg_service_mins: int
    description: str
    icon: str


@dataclass
class Counter:
    id: str
    name: str
    department_id: str
    is_active: bool = True
    assigned_staff: str = "Staff Officer"
    current_token_id: Optional[str] = None
    service_started_at: Optional[str] = None
    served_count_today: int = 0


@dataclass
class NotificationMessage:
    id: str
    timestamp: str
    title: str
    body: str
    type: str  # 'info', 'warning', 'success', 'urgent'
    read: bool = False


@dataclass
class Token:
    id: str
    token_number: str              # e.g., "MED-101"
    citizen_name: str
    phone: str
    domain: str                    # HOSPITAL, BANK, GOVERNMENT
    department_id: str
    department_name: str
    priority_level: PriorityLevel
    priority_reason: str
    created_at: str
    appointment_time: Optional[str] = None
    status: TokenStatus = TokenStatus.WAITING
    counter_id: Optional[str] = None
    counter_name: Optional[str] = None
    called_at: Optional[str] = None
    service_completed_at: Optional[str] = None
    estimated_wait_mins: int = 0
    people_ahead: int = 0
    notifications: List[Dict[str, Any]] = field(default_factory=list)
    calculated_score: float = 0.0  # Priority score calculated by rule engine

    def to_dict(self):
        return asdict(self)
