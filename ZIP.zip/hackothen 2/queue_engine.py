"""
QueueSmart AI - Core Intelligent Queue Management Engine
"""
from datetime import datetime, timedelta
from dataclasses import asdict
import random
import uuid
from typing import Dict, List, Optional, Any
from models import PriorityLevel, TokenStatus, DomainType, Department, Counter, Token, NotificationMessage


DOMAIN_PRESETS = {
    DomainType.HOSPITAL.value: {
        "title": "City Apex Super-Speciality Hospital",
        "subtitle": "Smart Healthcare Queue & Patient Triage System",
        "icon": "fa-hospital",
        "departments": [
            Department(id="h_emg", name="Emergency & Triage", code_prefix="EMG", avg_service_mins=5, description="Critical care, trauma, and acute cases", icon="fa-truck-medical"),
            Department(id="h_opd", name="General Medicine OPD", code_prefix="OPD", avg_service_mins=8, description="Consultation for general health and fever", icon="fa-stethoscope"),
            Department(id="h_rad", name="Radiology & Diagnostics", code_prefix="RAD", avg_service_mins=12, description="X-Ray, Ultrasound, and CT Scan appointments", icon="fa-x-ray"),
            Department(id="h_phm", name="Pharmacy & Billing", code_prefix="PHM", avg_service_mins=4, description="Prescription dispensation and insurance desk", icon="fa-pills"),
        ],
        "counters": [
            Counter(id="c1", name="Counter 1 (Triage Alpha)", department_id="h_emg", assigned_staff="Dr. Rajesh Verma", is_active=True),
            Counter(id="c2", name="Counter 2 (OPD Clinic A)", department_id="h_opd", assigned_staff="Dr. Sneha Roy", is_active=True),
            Counter(id="c3", name="Counter 3 (OPD Clinic B)", department_id="h_opd", assigned_staff="Dr. Amit Patel", is_active=True),
            Counter(id="c4", name="Counter 4 (Diagnostics 1)", department_id="h_rad", assigned_staff="Tech. Priya Sharma", is_active=True),
            Counter(id="c5", name="Counter 5 (Pharmacy Dispense)", department_id="h_phm", assigned_staff="Pharm. Manoj Kumar", is_active=True),
            Counter(id="c6", name="Counter 6 (Flex / Backup)", department_id="h_opd", assigned_staff="Reserve Officer", is_active=False),
        ]
    },
    DomainType.BANK.value: {
        "title": "National Union Smart Banking Hub",
        "subtitle": "Next-Gen Retail & Commercial Queue Navigator",
        "icon": "fa-building-columns",
        "departments": [
            Department(id="b_csh", name="Cash Deposit & Teller", code_prefix="CSH", avg_service_mins=4, description="Cash transactions, drafts, and cheque clearing", icon="fa-money-bill-wave"),
            Department(id="b_acc", name="KYC & Account Services", code_prefix="ACC", avg_service_mins=8, description="Account opening, address update, internet banking", icon="fa-id-card"),
            Department(id="b_lon", name="Loan & Credit Desk", code_prefix="LON", avg_service_mins=14, description="Home, personal, and business loan applications", icon="fa-hand-holding-dollar"),
            Department(id="b_wth", name="Forex & Wealth Advisory", code_prefix="WTH", avg_service_mins=10, description="International remittance and investments", icon="fa-chart-line"),
        ],
        "counters": [
            Counter(id="c1", name="Counter 1 (Express Teller)", department_id="b_csh", assigned_staff="Rohan Kapoor", is_active=True),
            Counter(id="c2", name="Counter 2 (Bulk Cash)", department_id="b_csh", assigned_staff="Ananya Sen", is_active=True),
            Counter(id="c3", name="Counter 3 (Customer Helpdesk)", department_id="b_acc", assigned_staff="Vikram Malhotra", is_active=True),
            Counter(id="c4", name="Counter 4 (Credit & Loan)", department_id="b_lon", assigned_staff="Deepika Nair", is_active=True),
            Counter(id="c5", name="Counter 5 (Forex / Wealth)", department_id="b_wth", assigned_staff="Sunil Joshi", is_active=True),
            Counter(id="c6", name="Counter 6 (Flex Counter)", department_id="b_csh", assigned_staff="Reserve Teller", is_active=False),
        ]
    },
    DomainType.GOVERNMENT.value: {
        "title": "Jan Suvidha Kendra (Citizen Center)",
        "subtitle": "Transparent Public Service Delivery & Queue System",
        "icon": "fa-landmark-flag",
        "departments": [
            Department(id="g_uid", name="Aadhaar & Identity Seva", code_prefix="UID", avg_service_mins=7, description="Biometric update, new enrollment, address correction", icon="fa-fingerprint"),
            Department(id="g_dl", name="Driving License & RTO", code_prefix="RTO", avg_service_mins=9, description="Learner license test, vehicle registration, transfer", icon="fa-car"),
            Department(id="g_wlf", name="Social Welfare & Housing", code_prefix="PMAY", avg_service_mins=11, description="PMAY housing, pension schemes, ration cards", icon="fa-house-chimney-user"),
            Department(id="g_rev", name="Land & Revenue Records", code_prefix="REV", avg_service_mins=12, description="Khasra/Khatauni verification, registry deeds", icon="fa-file-signature"),
        ],
        "counters": [
            Counter(id="c1", name="Counter 1 (Aadhaar Station)", department_id="g_uid", assigned_staff="M. K. Sharma", is_active=True),
            Counter(id="c2", name="Counter 2 (RTO Transport)", department_id="g_dl", assigned_staff="Suresh Raina", is_active=True),
            Counter(id="c3", name="Counter 3 (Welfare Schemes)", department_id="g_wlf", assigned_staff="Meenakshi Devi", is_active=True),
            Counter(id="c4", name="Counter 4 (Revenue Records)", department_id="g_rev", assigned_staff="Gopal Das", is_active=True),
            Counter(id="c5", name="Counter 5 (Citizen Express)", department_id="g_uid", assigned_staff="Pooja Pandey", is_active=True),
            Counter(id="c6", name="Counter 6 (Backup Window)", department_id="g_wlf", assigned_staff="Reserve Officer", is_active=False),
        ]
    }
}


class QueueSmartEngine:
    @staticmethod
    def _coerce_bool(value: Any, default: Optional[bool] = None) -> Optional[bool]:
        """Converts common user input forms into a proper boolean."""
        if value is None:
            return default
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            normalized = value.strip().lower()
            if normalized in {"true", "1", "yes", "y", "open"}:
                return True
            if normalized in {"false", "0", "no", "n", "closed"}:
                return False
        if isinstance(value, int) and value in (0, 1):
            return bool(value)
        return default

    def __init__(self, domain: str = DomainType.HOSPITAL.value):
        self.current_domain = domain
        self.sequence_counters: Dict[str, int] = {}
        self.departments: Dict[str, Department] = {}
        self.counters: Dict[str, Counter] = {}
        self.tokens: Dict[str, Token] = {}  # token_id -> Token
        self.completed_tokens: List[Token] = []
        self.announcements: List[Dict[str, Any]] = []
        self.ai_recommendations: List[Dict[str, Any]] = []
        self.activity_log: List[Dict[str, Any]] = []

        self.load_domain(domain)

    def load_domain(self, domain: str):
        """Initializes domain presets and populates initial sample data."""
        if domain not in DOMAIN_PRESETS:
            domain = DomainType.HOSPITAL.value
        self.current_domain = domain
        preset = DOMAIN_PRESETS[domain]

        self.departments = {dept.id: dept for dept in preset["departments"]}
        self.counters = {c.id: Counter(**c.__dict__) for c in preset["counters"]}
        self.tokens = {}
        self.completed_tokens = []
        self.announcements = []
        self.sequence_counters = {dept.code_prefix: 100 for dept in preset["departments"]}
        self.activity_log = []

        self._log_activity(f"System initialized in {domain} mode: {preset['title']}", "SYSTEM")
        self._seed_sample_data()
        self.recalculate_all_queues()

    def _log_activity(self, message: str, category: str = "INFO"):
        self.activity_log.insert(0, {
            "id": str(uuid.uuid4())[:8],
            "timestamp": datetime.now().strftime("%H:%M:%S"),
            "message": message,
            "category": category
        })
        if len(self.activity_log) > 50:
            self.activity_log = self.activity_log[:50]

    def _seed_sample_data(self):
        """Generates realistic initial active queue so the hackathon demo starts with rich live data."""
        sample_names = [
            ("Aarav Sharma", "9876543210", PriorityLevel.GENERAL, "Regular Walk-in"),
            ("Suman Devi", "9812345678", PriorityLevel.SENIOR_SPECIAL, "Senior Citizen (Age 72)"),
            ("Dr. Vikram Rathore", "9945123456", PriorityLevel.APPOINTMENT, "Pre-booked Slot 10:30 AM"),
            ("Ramesh Gupta", "9765432109", PriorityLevel.GENERAL, "Standard Walk-in"),
            ("Kavita Mehta", "9823456781", PriorityLevel.SENIOR_SPECIAL, "Differently Abled Support"),
            ("Mohd. Tariq", "9654321876", PriorityLevel.GENERAL, "Walk-in"),
            ("Sunita Verma", "9543216789", PriorityLevel.EMERGENCY if self.current_domain == DomainType.HOSPITAL.value else PriorityLevel.SENIOR_SPECIAL, "Acute Chest Pain / Triage" if self.current_domain == DomainType.HOSPITAL.value else "Senior Citizen (Age 68)"),
            ("Harish Kumar", "9432167890", PriorityLevel.GENERAL, "General Consultation"),
            ("Deepa Nair", "9321678901", PriorityLevel.APPOINTMENT, "Pre-booked Slot 11:00 AM"),
            ("Anita Das", "9210987654", PriorityLevel.GENERAL, "Regular Inquiry")
        ]

        dept_list = list(self.departments.values())
        now = datetime.now()

        for idx, (name, phone, priority, reason) in enumerate(sample_names):
            dept = dept_list[idx % len(dept_list)]
            if priority == PriorityLevel.EMERGENCY and self.current_domain == DomainType.HOSPITAL.value:
                # Emergency goes to emergency dept
                dept = self.departments.get("h_emg", dept)

            created_time = (now - timedelta(minutes=random.randint(5, 35))).strftime("%Y-%m-%d %H:%M:%S")
            self.sequence_counters[dept.code_prefix] += 1
            token_num = f"{dept.code_prefix}-{self.sequence_counters[dept.code_prefix]}"

            token = Token(
                id=str(uuid.uuid4())[:8],
                token_number=token_num,
                citizen_name=name,
                phone=phone,
                domain=self.current_domain,
                department_id=dept.id,
                department_name=dept.name,
                priority_level=priority,
                priority_reason=reason,
                created_at=created_time,
                status=TokenStatus.WAITING
            )
            # Add welcome SMS
            token.notifications.append({
                "id": str(uuid.uuid4())[:6],
                "timestamp": created_time.split()[1][:5],
                "title": f"Token Generated: {token.token_number}",
                "body": f"Namaste {name}. Your token for {dept.name} is confirmed. Please monitor live displays.",
                "type": "info"
            })
            self.tokens[token.id] = token

        # Assign 2-3 counters to be actively serving tokens
        active_counters = [c for c in self.counters.values() if c.is_active]
        for c in active_counters[:3]:
            # Find a waiting token for this counter's department
            dept_tokens = [t for t in self.tokens.values() if t.department_id == c.department_id and t.status == TokenStatus.WAITING]
            if dept_tokens:
                serving_token = dept_tokens[0]
                serving_token.status = TokenStatus.SERVING
                serving_token.counter_id = c.id
                serving_token.counter_name = c.name
                serving_token.called_at = (now - timedelta(minutes=random.randint(1, 4))).strftime("%Y-%m-%d %H:%M:%S")
                c.current_token_id = serving_token.id
                c.service_started_at = serving_token.called_at
                serving_token.notifications.append({
                    "id": str(uuid.uuid4())[:6],
                    "timestamp": serving_token.called_at.split()[1][:5],
                    "title": "Now Serving!",
                    "body": f"Please proceed immediately to {c.name} for your turn.",
                    "type": "urgent"
                })

    def generate_token(self, citizen_name: str, phone: str, department_id: str,
                       priority_level: str = PriorityLevel.GENERAL.value,
                       priority_reason: str = "Standard registration",
                       appointment_time: Optional[str] = None) -> Token:
        """Issues a new verified digital queue token with priority evaluation and estimated wait time."""
        if department_id not in self.departments:
            department_id = list(self.departments.keys())[0]

        dept = self.departments[department_id]
        self.sequence_counters[dept.code_prefix] += 1
        token_num = f"{dept.code_prefix}-{self.sequence_counters[dept.code_prefix]}"

        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        token_id = str(uuid.uuid4())[:8]

        citizen_name = str(citizen_name).strip() if citizen_name is not None else "Anonymous Citizen"
        phone = str(phone).strip() if phone is not None else "N/A"
        priority_reason = str(priority_reason).strip() or "Standard registration"
        if appointment_time is not None:
            appointment_time = str(appointment_time).strip() or None

        # Validated Priority enum
        try:
            priority_value = str(priority_level).strip()
            if hasattr(priority_level, "value"):
                priority_value = str(priority_level.value).strip()
            p_level = PriorityLevel(priority_value.upper())
        except Exception:
            p_level = PriorityLevel.GENERAL

        token = Token(
            id=token_id,
            token_number=token_num,
            citizen_name=citizen_name or "Anonymous Citizen",
            phone=phone or "N/A",
            domain=self.current_domain,
            department_id=dept.id,
            department_name=dept.name,
            priority_level=p_level,
            priority_reason=priority_reason,
            appointment_time=appointment_time,
            created_at=now_str,
            status=TokenStatus.WAITING
        )

        # Welcome notification
        token.notifications.append({
            "id": str(uuid.uuid4())[:6],
            "timestamp": datetime.now().strftime("%H:%M"),
            "title": f"Token Confirmed: {token.token_number}",
            "body": f"Welcome {token.citizen_name}! You are registered for {dept.name} ({p_level.value}). Watch your SMS & live screen.",
            "type": "info"
        })

        self.tokens[token.id] = token
        self._log_activity(f"Token {token.token_number} generated for {token.citizen_name} ({p_level.value})", "TOKEN")

        self.recalculate_all_queues()
        return self.tokens[token.id]

    def _calculate_priority_score(self, token: Token) -> float:
        """
        Calculates dynamic transparent priority score:
        Score = Base Priority Weight + Aging Bonus (points per minute waited).
        Ensures high priority gets fast service, while aging prevents general queue starvation.
        """
        base_weights = {
            PriorityLevel.EMERGENCY: 2000.0,
            PriorityLevel.SENIOR_SPECIAL: 800.0,
            PriorityLevel.APPOINTMENT: 400.0,
            PriorityLevel.GENERAL: 100.0
        }
        base = base_weights.get(token.priority_level, 100.0)

        # Aging factor: minutes waited since creation
        try:
            created_dt = datetime.strptime(token.created_at, "%Y-%m-%d %H:%M:%S")
            mins_waiting = max(0, (datetime.now() - created_dt).total_seconds() / 60.0)
        except Exception:
            mins_waiting = 0.0

        # Aging bonus: 4 points per minute waited
        aging_bonus = mins_waiting * 4.0
        return base + aging_bonus

    def recalculate_all_queues(self):
        """
        Updates priority ordering, queue positions, estimated waiting times,
        and triggers approaching notification alerts.
        """
        for dept_id, dept in self.departments.items():
            # Get active counters for this dept
            active_counters = [c for c in self.counters.values() if c.is_active and c.department_id == dept_id]
            counter_count = max(1, len(active_counters))

            # Get waiting tokens for this dept
            waiting_tokens = [
                t for t in self.tokens.values()
                if t.department_id == dept_id and t.status in [TokenStatus.WAITING, TokenStatus.APPROACHING]
            ]

            # Calculate dynamic priority score for each
            for t in waiting_tokens:
                t.calculated_score = self._calculate_priority_score(t)

            # Sort descending by priority score
            waiting_tokens.sort(key=lambda t: t.calculated_score, reverse=True)

            # Assign people ahead and estimated wait times
            avg_service_mins = dept.avg_service_mins

            for idx, token in enumerate(waiting_tokens):
                people_ahead = idx
                token.people_ahead = people_ahead

                # Dynamic wait formula: (people_ahead * avg_service) / active_counters
                estimated_mins = int(round((people_ahead * avg_service_mins) / counter_count))
                if estimated_mins < 2 and people_ahead > 0:
                    estimated_mins = 2
                elif people_ahead == 0:
                    estimated_mins = 1  # Next in line!

                old_est = token.estimated_wait_mins
                token.estimated_wait_mins = estimated_mins

                # Check status transition to APPROACHING
                if people_ahead <= 1 and token.status == TokenStatus.WAITING:
                    token.status = TokenStatus.APPROACHING
                    token.notifications.append({
                        "id": str(uuid.uuid4())[:6],
                        "timestamp": datetime.now().strftime("%H:%M"),
                        "title": "🔔 Your Turn is Approaching!",
                        "body": f"You are next in line ({people_ahead} person ahead). Please stand near the service counter area.",
                        "type": "warning"
                    })
                    self._log_activity(f"Approaching alert sent to {token.token_number} ({token.citizen_name})", "ALERT")

                # If wait time changed significantly (> 5 mins diff)
                elif old_est > 0 and abs(estimated_mins - old_est) >= 5:
                    token.notifications.append({
                        "id": str(uuid.uuid4())[:6],
                        "timestamp": datetime.now().strftime("%H:%M"),
                        "title": "⏱️ Estimated Time Updated",
                        "body": f"Queue progress update: Your revised estimated wait time is {estimated_mins} minutes.",
                        "type": "info"
                    })

        self._evaluate_ai_optimization()

    def call_next(self, counter_id: str) -> Optional[Token]:
        """Counter staff calls the next highest-priority citizen in their queue."""
        if counter_id not in self.counters:
            return None

        counter = self.counters[counter_id]
        if not counter.is_active:
            return None

        # If currently serving a token, auto-complete it first
        if counter.current_token_id and counter.current_token_id in self.tokens:
            self.complete_service(counter_id)

        # Find eligible waiting tokens for this counter's department
        eligible_tokens = [
            t for t in self.tokens.values()
            if t.department_id == counter.department_id and t.status in [TokenStatus.WAITING, TokenStatus.APPROACHING]
        ]

        if not eligible_tokens:
            # Check if flex counter: can serve longest waiting token in any department!
            longest_waiting = [
                t for t in self.tokens.values()
                if t.status in [TokenStatus.WAITING, TokenStatus.APPROACHING]
            ]
            if not longest_waiting:
                return None
            longest_waiting.sort(key=lambda t: self._calculate_priority_score(t), reverse=True)
            chosen_token = longest_waiting[0]
        else:
            eligible_tokens.sort(key=lambda t: self._calculate_priority_score(t), reverse=True)
            chosen_token = eligible_tokens[0]

        # Update token
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        chosen_token.status = TokenStatus.SERVING
        chosen_token.counter_id = counter.id
        chosen_token.counter_name = counter.name
        chosen_token.called_at = now_str
        chosen_token.people_ahead = 0
        chosen_token.estimated_wait_mins = 0

        # Update counter
        counter.current_token_id = chosen_token.id
        counter.service_started_at = now_str

        # Add Notification
        chosen_token.notifications.append({
            "id": str(uuid.uuid4())[:6],
            "timestamp": datetime.now().strftime("%H:%M"),
            "title": f"📢 Proceed to {counter.name} Now!",
            "body": f"Token {chosen_token.token_number}: Officer {counter.assigned_staff} is ready to serve you at {counter.name}.",
            "type": "urgent"
        })

        # Add to public announcements for text-to-speech audio broadcast
        announcement = {
            "id": str(uuid.uuid4())[:6],
            "token_number": chosen_token.token_number,
            "counter_name": counter.name,
            "department_name": chosen_token.department_name,
            "text": f"Token number {chosen_token.token_number}, please proceed to {counter.name}",
            "timestamp": datetime.now().strftime("%H:%M:%S")
        }
        self.announcements.insert(0, announcement)
        if len(self.announcements) > 20:
            self.announcements = self.announcements[:20]

        self._log_activity(f"{counter.name} called Token {chosen_token.token_number} ({chosen_token.citizen_name})", "CALL")
        self.recalculate_all_queues()
        return chosen_token

    def complete_service(self, counter_id: str) -> Optional[Token]:
        """Marks current token service as completed and records metrics."""
        if counter_id not in self.counters:
            return None
        counter = self.counters[counter_id]
        if not counter.current_token_id or counter.current_token_id not in self.tokens:
            return None

        token = self.tokens[counter.current_token_id]
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        token.status = TokenStatus.COMPLETED
        token.service_completed_at = now_str

        token.notifications.append({
            "id": str(uuid.uuid4())[:6],
            "timestamp": datetime.now().strftime("%H:%M"),
            "title": "✅ Service Completed",
            "body": f"Your consultation at {counter.name} has concluded. Thank you for using QueueSmart AI!",
            "type": "success"
        })

        counter.served_count_today += 1
        counter.current_token_id = None
        counter.service_started_at = None

        self.completed_tokens.insert(0, token)
        self._log_activity(f"Completed service for {token.token_number} at {counter.name}", "COMPLETE")
        self.recalculate_all_queues()
        return token

    def mark_no_show(self, counter_id: str) -> Optional[Token]:
        """Marks currently called citizen as No-Show if they failed to arrive."""
        if counter_id not in self.counters:
            return None
        counter = self.counters[counter_id]
        if not counter.current_token_id or counter.current_token_id not in self.tokens:
            return None

        token = self.tokens[counter.current_token_id]
        token.status = TokenStatus.NO_SHOW

        token.notifications.append({
            "id": str(uuid.uuid4())[:6],
            "timestamp": datetime.now().strftime("%H:%M"),
            "title": "⚠️ Marked as No-Show",
            "body": "You were called to the counter but did not respond. Please visit reception to rejoin the queue.",
            "type": "warning"
        })

        counter.current_token_id = None
        counter.service_started_at = None

        self._log_activity(f"Token {token.token_number} marked as NO-SHOW at {counter.name}", "NO_SHOW")
        self.recalculate_all_queues()
        return token

    def toggle_counter_status(self, counter_id: str, is_active: Optional[bool] = None) -> Counter:
        """Opens or closes a service counter."""
        if counter_id not in self.counters:
            raise ValueError("Counter not found")
        counter = self.counters[counter_id]

        coerced_value = self._coerce_bool(is_active)
        if is_active is None:
            counter.is_active = not counter.is_active
        elif coerced_value is None:
            raise ValueError("Counter status must be a boolean value")
        else:
            counter.is_active = coerced_value

        status_text = "OPENED" if counter.is_active else "CLOSED"
        self._log_activity(f"{counter.name} {status_text} by administrator", "COUNTER")
        self.recalculate_all_queues()
        return counter

    def reassign_counter(self, counter_id: str, new_department_id: str) -> Counter:
        """Dynamically switches a counter's department assignment."""
        if counter_id not in self.counters or new_department_id not in self.departments:
            raise ValueError("Invalid counter or department")
        counter = self.counters[counter_id]
        counter.department_id = new_department_id
        new_dept = self.departments[new_department_id]
        self._log_activity(f"{counter.name} reassigned to {new_dept.name}", "CONFIG")
        self.recalculate_all_queues()
        return counter

    def add_counter(self, name: str, department_id: str, staff_name: str = "Support Officer") -> Counter:
        """Adds a new service counter dynamically."""
        if department_id not in self.departments:
            raise ValueError("Department not found")

        cid = f"c{len(self.counters) + 1}"
        new_counter = Counter(
            id=cid,
            name=str(name).strip() or "New Service Counter",
            department_id=department_id,
            is_active=True,
            assigned_staff=str(staff_name).strip() or "Support Officer"
        )
        self.counters[cid] = new_counter
        self._log_activity(f"New counter {new_counter.name} opened for {self.departments[department_id].name}", "COUNTER")
        self.recalculate_all_queues()
        return new_counter

    def _evaluate_ai_optimization(self):
        """
        AI-Powered Queue Optimization & Overcrowding Detector:
        Analyzes queue length, arrival velocity, and service rate per department.
        Generates actionable suggestions to open counters, reallocate idle staff, or warn of bottlenecks.
        """
        recs = []
        SLA_MAX_WAIT_MINS = 15  # Target service standard

        for dept_id, dept in self.departments.items():
            waiting_tokens = [
                t for t in self.tokens.values()
                if t.department_id == dept_id and t.status in [TokenStatus.WAITING, TokenStatus.APPROACHING]
            ]
            active_counters = [c for c in self.counters.values() if c.is_active and c.department_id == dept_id]
            closed_counters = [c for c in self.counters.values() if not c.is_active and c.department_id == dept_id]

            queue_length = len(waiting_tokens)
            active_count = len(active_counters)
            max_est_wait = max([t.estimated_wait_mins for t in waiting_tokens]) if waiting_tokens else 0

            # 1. Bottleneck / Overcrowding Alert
            if queue_length >= 4 or max_est_wait > SLA_MAX_WAIT_MINS:
                # Find available backup counter or underutilized counter in other depts
                backup = closed_counters[0] if closed_counters else None
                donor_counter = None

                if not backup:
                    # Look for active counter in department with 0 queue
                    for other_id, other_dept in self.departments.items():
                        if other_id == dept_id:
                            continue
                        other_waiting = [t for t in self.tokens.values() if t.department_id == other_id and t.status in [TokenStatus.WAITING, TokenStatus.APPROACHING]]
                        other_active = [c for c in self.counters.values() if c.is_active and c.department_id == other_id]
                        if len(other_waiting) <= 1 and len(other_active) > 1:
                            donor_counter = other_active[-1]
                            break

                recs.append({
                    "id": f"rec_{dept_id}_{queue_length}",
                    "severity": "CRITICAL" if max_est_wait > 25 else "WARNING",
                    "department_id": dept_id,
                    "department_name": dept.name,
                    "title": f"Overcrowding Surge Detected in {dept.name}",
                    "description": f"{queue_length} citizens waiting. Estimated wait time peaked at {max_est_wait} mins (SLA target: {SLA_MAX_WAIT_MINS} mins).",
                    "suggested_action": f"Activate backup counter or reallocate staff to {dept.name}",
                    "action_type": "ACTIVATE_COUNTER" if backup else ("REALLOCATE_COUNTER" if donor_counter else "ADD_STAFF"),
                    "target_counter_id": backup.id if backup else (donor_counter.id if donor_counter else None),
                    "target_counter_name": backup.name if backup else (donor_counter.name if donor_counter else "New Flex Window"),
                    "impact": f"Reduces average waiting time by ~{min(45, round((1.0 - (active_count / max(1, active_count + 1))) * 100))}%"
                })

            # 2. Underutilization / Efficiency Optimization
            elif queue_length == 0 and active_count > 1:
                recs.append({
                    "id": f"rec_idle_{dept_id}",
                    "severity": "INFO",
                    "department_id": dept_id,
                    "department_name": dept.name,
                    "title": f"Counter Underutilization in {dept.name}",
                    "description": f"0 citizens waiting while {active_count} counters are active.",
                    "suggested_action": f"Consider placing one counter on standby or reassigning to busier departments.",
                    "action_type": "STANDBY",
                    "target_counter_id": active_counters[-1].id,
                    "target_counter_name": active_counters[-1].name,
                    "impact": "Optimizes staff workload and prevents counter idle time."
                })

        self.ai_recommendations = recs

    def apply_ai_recommendation(self, rec_id: str) -> Dict[str, Any]:
        """One-click execution of an AI optimization proposal."""
        for rec in self.ai_recommendations:
            if rec["id"] == rec_id:
                if rec["action_type"] == "ACTIVATE_COUNTER" and rec.get("target_counter_id"):
                    self.toggle_counter_status(rec["target_counter_id"], is_active=True)
                    self._log_activity(f"AI Action Applied: Activated {rec['target_counter_name']} for {rec['department_name']}", "AI_AUTO")
                    return {"success": True, "message": f"Activated {rec['target_counter_name']}!"}
                elif rec["action_type"] == "REALLOCATE_COUNTER" and rec.get("target_counter_id"):
                    self.reassign_counter(rec["target_counter_id"], rec["department_id"])
                    self._log_activity(f"AI Action Applied: Reallocated {rec['target_counter_name']} to {rec['department_name']}", "AI_AUTO")
                    return {"success": True, "message": f"Reallocated {rec['target_counter_name']} to {rec['department_name']}!"}
                elif rec["action_type"] == "STANDBY" and rec.get("target_counter_id"):
                    self.toggle_counter_status(rec["target_counter_id"], is_active=False)
                    self._log_activity(f"AI Action Applied: Put {rec['target_counter_name']} on standby", "AI_AUTO")
                    return {"success": True, "message": f"Put {rec['target_counter_name']} on standby."}
        return {"success": False, "message": "Recommendation not found or not actionable."}

    def simulate_random_citizen(self) -> Token:
        """Simulates an arriving citizen for dynamic live presentation demonstrations."""
        names = ["Sanjay Rao", "Pooja Hegde", "Manish Tiwari", "Fatima Bi", "Gurpreet Singh", "Kavya Reddy", "Arjun Saxena", "Meera Sen"]
        priorities = [
            (PriorityLevel.GENERAL, "Regular Walk-in"),
            (PriorityLevel.GENERAL, "Regular Walk-in"),
            (PriorityLevel.SENIOR_SPECIAL, "Senior Citizen (Age 65+)"),
            (PriorityLevel.APPOINTMENT, "Scheduled Digital Slot"),
        ]
        if self.current_domain == DomainType.HOSPITAL.value:
            priorities.append((PriorityLevel.EMERGENCY, "Acute Medical Attention"))

        chosen_name = random.choice(names)
        chosen_p, chosen_reason = random.choice(priorities)
        dept = random.choice(list(self.departments.values()))

        return self.generate_token(
            citizen_name=chosen_name,
            phone=f"98{random.randint(10000000, 99999999)}",
            department_id=dept.id,
            priority_level=chosen_p.value,
            priority_reason=chosen_reason
        )

    def advance_token_for_demo(self, token_id: str) -> Optional[Token]:
        """
        Interactive Hackathon Pitch Demo Booster:
        Fast-forwards a specific citizen's token to the next stage
        (WAITING -> APPROACHING -> SERVING -> COMPLETED).
        """
        if token_id not in self.tokens:
            return None
        token = self.tokens[token_id]

        if token.status == TokenStatus.WAITING:
            token.status = TokenStatus.APPROACHING
            token.people_ahead = 1
            token.estimated_wait_mins = 2
            token.notifications.append({
                "id": str(uuid.uuid4())[:6],
                "timestamp": datetime.now().strftime("%H:%M"),
                "title": "🔔 Your Turn is Approaching! (1 Ahead)",
                "body": f"Token {token.token_number}: You are next in line for {token.department_name}. Please move towards the counter area.",
                "type": "warning"
            })
            self._log_activity(f"Demo Fast-Forward: {token.token_number} moved to APPROACHING", "DEMO")
        elif token.status == TokenStatus.APPROACHING:
            # Find an active counter for this department or flex counter
            matching_counters = [c for c in self.counters.values() if c.is_active and c.department_id == token.department_id]
            counter = matching_counters[0] if matching_counters else [c for c in self.counters.values() if c.is_active][0]

            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            token.status = TokenStatus.SERVING
            token.counter_id = counter.id
            token.counter_name = counter.name
            token.called_at = now_str
            token.people_ahead = 0
            token.estimated_wait_mins = 0

            counter.current_token_id = token.id
            counter.service_started_at = now_str

            token.notifications.append({
                "id": str(uuid.uuid4())[:6],
                "timestamp": datetime.now().strftime("%H:%M"),
                "title": f"📢 NOW SERVING at {counter.name}!",
                "body": f"Please walk up to {counter.name}. Officer {counter.assigned_staff} is ready.",
                "type": "urgent"
            })

            announcement = {
                "id": str(uuid.uuid4())[:6],
                "token_number": token.token_number,
                "counter_name": counter.name,
                "department_name": token.department_name,
                "text": f"Token number {token.token_number}, please proceed to {counter.name}",
                "timestamp": datetime.now().strftime("%H:%M:%S")
            }
            self.announcements.insert(0, announcement)
            self._log_activity(f"Demo Fast-Forward: {token.token_number} called to {counter.name}", "CALL")
        elif token.status == TokenStatus.SERVING:
            if token.counter_id and token.counter_id in self.counters:
                return self.complete_service(token.counter_id)

        self.recalculate_all_queues()
        return token

    def simulate_surge(self, dept_id: Optional[str] = None, count: int = 4) -> List[Token]:
        """Simulates sudden rush-hour influx in a department to trigger AI bottleneck alerts."""
        if not dept_id or dept_id not in self.departments:
            dept_id = list(self.departments.keys())[0]

        dept = self.departments[dept_id]
        names = ["Aarti Kapoor", "Vipin Chawla", "Tarun Bhasin", "Sunita Sen", "Farhan Akhtar", "Kavya Menon"]
        created_tokens = []

        for i in range(min(count, len(names))):
            t = self.generate_token(
                citizen_name=f"{names[i]} (Surge)",
                phone=f"98{random.randint(10000000, 99999999)}",
                department_id=dept.id,
                priority_level=PriorityLevel.GENERAL.value,
                priority_reason="Rush-hour walk-in spike"
            )
            created_tokens.append(t)

        self._log_activity(f"⚡ Artificial surge simulated: {count} citizens arrived at {dept.name}", "SURGE")
        self.recalculate_all_queues()
        return created_tokens

    def transfer_token(self, token_id: str, new_dept_id: str, note: str = "Department Transfer") -> Optional[Token]:
        """Transfers a citizen to a secondary department (e.g. Consultation -> Diagnostics/Pharmacy)."""
        if token_id not in self.tokens or new_dept_id not in self.departments:
            return None

        token = self.tokens[token_id]
        new_dept = self.departments[new_dept_id]
        old_dept_name = token.department_name

        # Clear any counter assignment
        if token.counter_id and token.counter_id in self.counters:
            counter = self.counters[token.counter_id]
            if counter.current_token_id == token.id:
                counter.current_token_id = None
                counter.service_started_at = None

        token.department_id = new_dept.id
        token.department_name = new_dept.name
        token.status = TokenStatus.WAITING
        token.counter_id = None
        token.counter_name = None
        token.priority_reason = f"Transferred from {old_dept_name}: {note}"

        token.notifications.append({
            "id": str(uuid.uuid4())[:6],
            "timestamp": datetime.now().strftime("%H:%M"),
            "title": f"🔄 Transferred to {new_dept.name}",
            "body": f"Your ticket was transferred to {new_dept.name}. You have been placed in line with priority seniority.",
            "type": "info"
        })

        self._log_activity(f"Token {token.token_number} transferred from {old_dept_name} to {new_dept.name}", "TRANSFER")
        self.recalculate_all_queues()
        return token

    def get_full_state(self) -> Dict[str, Any]:
        """Provides complete synchronized state for frontend UI."""
        waiting_tokens = [t.to_dict() for t in self.tokens.values() if t.status in [TokenStatus.WAITING, TokenStatus.APPROACHING]]
        serving_tokens = [t.to_dict() for t in self.tokens.values() if t.status == TokenStatus.SERVING]
        completed_tokens = [t.to_dict() for t in self.completed_tokens[:15]]

        # Calculate high level operational statistics
        total_waiting = len(waiting_tokens)
        total_serving = len(serving_tokens)
        total_served = len(self.completed_tokens)
        active_counters_count = len([c for c in self.counters.values() if c.is_active])

        all_est_waits = [t["estimated_wait_mins"] for t in waiting_tokens]
        avg_wait_mins = round(sum(all_est_waits) / max(1, len(all_est_waits)), 1) if all_est_waits else 0

        # Department breakdown
        dept_stats = []
        for d in self.departments.values():
            d_waiting = [t for t in waiting_tokens if t["department_id"] == d.id]
            d_serving = [t for t in serving_tokens if t["department_id"] == d.id]
            d_counters = [c for c in self.counters.values() if c.is_active and c.department_id == d.id]
            dept_stats.append({
                "id": d.id,
                "name": d.name,
                "code_prefix": d.code_prefix,
                "avg_service_mins": d.avg_service_mins,
                "waiting_count": len(d_waiting),
                "serving_count": len(d_serving),
                "active_counters": len(d_counters),
                "icon": d.icon,
                "est_wait_max": max([t["estimated_wait_mins"] for t in d_waiting]) if d_waiting else 0
            })

        preset_info = DOMAIN_PRESETS[self.current_domain]

        # Hourly traffic simulation for charts
        hourly_labels = ["09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM"]
        hourly_arrivals = [12, 28, 45, 38, 19, 34, 29, max(14, total_waiting + total_serving)]
        hourly_wait_trend = [3.5, 6.8, 14.2, 11.0, 4.5, 9.2, 7.8, avg_wait_mins]
        sla_compliance = round(max(68.0, min(99.2, 100.0 - (len(self.ai_recommendations) * 6.5))), 1)

        return {
            "domain": self.current_domain,
            "title": preset_info["title"],
            "subtitle": preset_info["subtitle"],
            "icon": preset_info["icon"],
            "available_domains": list(DOMAIN_PRESETS.keys()),
            "departments": [asdict(d) for d in self.departments.values()],
            "counters": [asdict(c) for c in self.counters.values()],
            "waiting_tokens": waiting_tokens,
            "serving_tokens": serving_tokens,
            "completed_tokens": completed_tokens,
            "announcements": self.announcements[:6],
            "ai_recommendations": self.ai_recommendations,
            "activity_log": self.activity_log[:15],
            "stats": {
                "total_waiting": total_waiting,
                "total_serving": total_serving,
                "total_served": total_served,
                "active_counters_count": active_counters_count,
                "total_counters_count": len(self.counters),
                "avg_wait_mins": avg_wait_mins,
                "sla_compliance": sla_compliance,
                "hourly_labels": hourly_labels,
                "hourly_arrivals": hourly_arrivals,
                "hourly_wait_trend": hourly_wait_trend,
                "dept_stats": dept_stats
            },
            "disclaimer": "Waiting-time predictions are algorithmic estimates based on queue velocity, active counters, and priority weighting. Predictions are subject to consultation variance and do not constitute legal guarantees."
        }
