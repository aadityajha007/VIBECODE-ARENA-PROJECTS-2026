"""
QueueSmart AI - Comprehensive Automated System Audit & Bug Detector
Tests every single backend endpoint, edge case, and checks all DOM element IDs & JS bindings in HTML.
"""
import re
import unittest
import json
from app import app, engine
from models import PriorityLevel, DomainType, TokenStatus


class ComprehensiveBackendTestSuite(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()
        engine.load_domain(DomainType.HOSPITAL.value)

    # 1. State & Domains
    def test_domain_switching_all(self):
        for dom in [DomainType.HOSPITAL.value, DomainType.BANK.value, DomainType.GOVERNMENT.value]:
            res = self.client.post('/api/sim/domain', json={"domain": dom})
            self.assertEqual(res.status_code, 200)
            data = res.get_json()
            self.assertTrue(data["success"])
            self.assertEqual(data["domain"], dom)

            # verify state matches
            state_res = self.client.get('/api/state')
            state = state_res.get_json()
            self.assertEqual(state["domain"], dom)
            self.assertGreater(len(state["departments"]), 0)
            self.assertGreater(len(state["counters"]), 0)

    def test_invalid_domain_fallback(self):
        res = self.client.post('/api/sim/domain', json={"domain": "INVALID_SECTOR"})
        self.assertEqual(res.status_code, 200)
        # Should fallback safely to HOSPITAL
        state = self.client.get('/api/state').get_json()
        self.assertEqual(state["domain"], DomainType.HOSPITAL.value)

    # 2. Token Lifecycle & Edge Cases
    def test_token_generation_valid_and_edge_cases(self):
        dept_id = list(engine.departments.keys())[0]

        # Standard valid
        res = self.client.post('/api/token/generate', json={
            "citizen_name": "Deepak Verma",
            "phone": "9876543210",
            "department_id": dept_id,
            "priority_level": "SENIOR_SPECIAL",
            "priority_reason": "Senior 65y"
        })
        self.assertEqual(res.status_code, 200)
        t = res.get_json()["token"]
        self.assertEqual(t["citizen_name"], "Deepak Verma")
        self.assertEqual(t["priority_level"], "SENIOR_SPECIAL")

        # Missing name (should default safely)
        res2 = self.client.post('/api/token/generate', json={
            "phone": "9876543210",
            "department_id": dept_id
        })
        self.assertEqual(res2.status_code, 200)
        self.assertEqual(res2.get_json()["token"]["citizen_name"], "Anonymous Citizen")

        # Missing department_id (should return 400 error)
        res3 = self.client.post('/api/token/generate', json={"citizen_name": "Fail Test"})
        self.assertEqual(res3.status_code, 400)

        # Invalid priority level (should fallback to GENERAL safely)
        res4 = self.client.post('/api/token/generate', json={
            "citizen_name": "Fallback Test",
            "department_id": dept_id,
            "priority_level": "SUPER_VIP_NON_EXISTENT"
        })
        self.assertEqual(res4.status_code, 200)
        self.assertEqual(res4.get_json()["token"]["priority_level"], "GENERAL")

    def test_token_lookup_and_not_found(self):
        dept_id = list(engine.departments.keys())[0]
        t = engine.generate_token("Lookup Test", "9876543210", dept_id)

        res = self.client.get(f'/api/token/{t.id}')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data["token"]["id"], t.id)

        # Non-existing token 404
        res_404 = self.client.get('/api/token/non_existing_99999')
        self.assertEqual(res_404.status_code, 404)

    # 3. Counter Workflow: Call Next, Complete, No-Show, Transfer
    def test_counter_call_complete_flow(self):
        dept_id = list(engine.departments.keys())[0]
        counter = [c for c in engine.counters.values() if c.is_active and c.department_id == dept_id][0]

        # Generate fresh token
        t = engine.generate_token("Queue Flow Test", "9876543210", dept_id)

        # Call Next
        res_call = self.client.post('/api/counter/call-next', json={"counter_id": counter.id})
        self.assertEqual(res_call.status_code, 200)
        data_call = res_call.get_json()
        self.assertTrue(data_call["success"])
        serving_token = data_call["token"]

        # Counter complete
        res_comp = self.client.post('/api/counter/complete', json={"counter_id": counter.id})
        self.assertEqual(res_comp.status_code, 200)
        data_comp = res_comp.get_json()
        self.assertTrue(data_comp["success"])
        self.assertEqual(data_comp["token"]["status"], "COMPLETED")

        # Calling complete again when no one is serving
        res_comp_empty = self.client.post('/api/counter/complete', json={"counter_id": counter.id})
        self.assertEqual(res_comp_empty.status_code, 200)
        self.assertFalse(res_comp_empty.get_json()["success"])

    def test_counter_no_show_flow(self):
        dept_id = list(engine.departments.keys())[0]
        counter = [c for c in engine.counters.values() if c.is_active and c.department_id == dept_id][0]

        # Call next
        self.client.post('/api/counter/call-next', json={"counter_id": counter.id})

        # Mark no show
        res_noshow = self.client.post('/api/counter/no-show', json={"counter_id": counter.id})
        self.assertEqual(res_noshow.status_code, 200)
        data = res_noshow.get_json()
        self.assertTrue(data["success"])
        self.assertEqual(data["token"]["status"], "NO_SHOW")

    def test_counter_transfer_flow(self):
        dept_ids = list(engine.departments.keys())
        self.assertGreaterEqual(len(dept_ids), 2)
        t = engine.generate_token("Transfer Flow Test", "9876543210", dept_ids[0])

        res = self.client.post('/api/token/transfer', json={
            "token_id": t.id,
            "department_id": dept_ids[1],
            "note": "Referred to diagnostics"
        })
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data["success"])
        self.assertEqual(data["token"]["department_id"], dept_ids[1])

    # 4. AI Optimization & Surge
    def test_surge_and_ai_recommendation_cycle(self):
        dept_id = list(engine.departments.keys())[0]

        # Trigger surge
        res_surge = self.client.post('/api/sim/surge', json={"department_id": dept_id, "count": 5})
        self.assertEqual(res_surge.status_code, 200)
        self.assertTrue(res_surge.get_json()["success"])

        # Fetch state and check recommendations
        state = self.client.get('/api/state').get_json()
        recs = state["ai_recommendations"]
        self.assertGreater(len(recs), 0)

        # Apply top recommendation
        rec_id = recs[0]["id"]
        res_apply = self.client.post('/api/ai/apply', json={"recommendation_id": rec_id})
        self.assertEqual(res_apply.status_code, 200)
        self.assertTrue(res_apply.get_json()["success"])

    # 5. Fast-Forward Demo Endpoint
    def test_pitch_demo_advance_token(self):
        dept_id = list(engine.departments.keys())[0]
        t = engine.generate_token("Fast Forward Demo Test", "9876543210", dept_id)
        self.assertEqual(t.status, TokenStatus.WAITING)

        # Advance 1: WAITING -> APPROACHING
        res1 = self.client.post('/api/token/advance', json={"token_id": t.id})
        self.assertEqual(res1.status_code, 200)
        self.assertEqual(res1.get_json()["token"]["status"], "APPROACHING")

        # Advance 2: APPROACHING -> SERVING
        res2 = self.client.post('/api/token/advance', json={"token_id": t.id})
        self.assertEqual(res2.status_code, 200)
        self.assertEqual(res2.get_json()["token"]["status"], "SERVING")

        # Advance 3: SERVING -> COMPLETED
        res3 = self.client.post('/api/token/advance', json={"token_id": t.id})
        self.assertEqual(res3.status_code, 200)
        self.assertEqual(res3.get_json()["token"]["status"], "COMPLETED")

    # 6. Admin Counter Management
    def test_admin_add_toggle_reassign_counter(self):
        dept_ids = list(engine.departments.keys())

        # Add counter
        res_add = self.client.post('/api/counter/add', json={
            "name": "Audit Test Counter Window",
            "department_id": dept_ids[0],
            "staff_name": "Test Inspector Officer"
        })
        self.assertEqual(res_add.status_code, 200)
        cid = res_add.get_json()["counter"]["id"]

        # Toggle counter
        res_toggle = self.client.post('/api/counter/toggle', json={"counter_id": cid})
        self.assertEqual(res_toggle.status_code, 200)

        # Reassign department
        res_reassign = self.client.post('/api/counter/reassign', json={
            "counter_id": cid,
            "department_id": dept_ids[1]
        })
        self.assertEqual(res_reassign.status_code, 200)
        self.assertEqual(res_reassign.get_json()["counter"]["department_id"], dept_ids[1])


class FrontendHtmlIntegrityCheck(unittest.TestCase):
    def test_html_and_dom_ids_integrity(self):
        with open('templates/index.html', 'r', encoding='utf-8') as f:
            html = f.read()

        # Extract all getElementById occurrences in <script>
        js_ids = set(re.findall(r"document\.getElementById\(['\"]([^'\"]+)['\"]\)", html))
        self.assertGreater(len(js_ids), 20, "Should have plenty of referenced DOM IDs")

        # Extract all id="..." in HTML
        html_ids = set(re.findall(r'\bid=["\']([^"\']+)["\']', html))

        missing_ids = []
        for jid in js_ids:
            # Some IDs might be dynamically generated or exist in HTML
            if jid not in html_ids:
                missing_ids.append(jid)

        print(f"\n[Audit] Verified {len(js_ids)} JavaScript DOM element IDs.")
        if missing_ids:
            print(f"[Audit Warning] Missing DOM IDs referenced in JS: {missing_ids}")
        self.assertEqual(missing_ids, [], f"Missing DOM elements in HTML: {missing_ids}")

    def test_onclick_function_bindings(self):
        with open('templates/index.html', 'r', encoding='utf-8') as f:
            html = f.read()

        # Find all onclick="functionName(...)"
        onclick_calls = re.findall(r'onclick=["\']([a-zA-Z0-9_]+)\(', html)
        self.assertGreater(len(onclick_calls), 10)

        # Find all function functionName( in <script>
        defined_functions = set(re.findall(r'function\s+([a-zA-Z0-9_]+)\s*\(', html))

        # Async functions
        async_functions = set(re.findall(r'async\s+function\s+([a-zA-Z0-9_]+)\s*\(', html))
        all_funcs = defined_functions.union(async_functions)

        missing_funcs = []
        for fn in set(onclick_calls):
            if fn not in all_funcs:
                missing_funcs.append(fn)

        print(f"[Audit] Verified {len(set(onclick_calls))} HTML onclick button bindings.")
        if missing_funcs:
            print(f"[Audit Warning] Undefined onclick functions: {missing_funcs}")
        self.assertEqual(missing_funcs, [], f"Undefined onclick functions: {missing_funcs}")


if __name__ == '__main__':
    unittest.main()
