# QueueSmart AI 🚀
### AI-Powered Smart Queue Management & Live Flow Optimization Platform
**Built for Vibe Code Arena Hackathon — Problem Statement 6**

---

## 🌟 Executive Summary
Long waiting times at hospitals, banks, and government service centers cause overcrowding, citizen frustration, and inefficient counter utilization. **QueueSmart AI** is a next-generation intelligent queue operating platform designed to eliminate blind waiting, provide explainable mathematical wait-time forecasts, deliver simulated SMS push updates, and empower administrators with AI-driven counter balancing.

---

## ✨ Key Features & Problem Statement Fulfillment

| Feature Requirement | Implementation in QueueSmart AI |
| :--- | :--- |
| **1. Digital Queue Registration & Token Generation** | Responsive kiosk & pass view. Generates unique tokens (e.g. `OPD-102`, `CSH-105`) with printable digital boarding pass and QR representation. |
| **2. Dynamic Waiting-Time Prediction** | Algorithmic estimation based on: $(\text{People Ahead} \times \text{Avg Service Mins}) / \text{Active Counters}$. Includes clear disclaimer that predictions are advisory estimates. |
| **3. Live Queue Dashboard (Big Screen / TV View)** | Airport/Hospital flight-board style UI with "Now Serving" counter cards, Up Next ticker, and browser speech-synthesis audio callout (*"Token OPD-102 please proceed to Counter 2"*). |
| **4. AI Queue Optimization Engine** | Detects overcrowding bottlenecks (queue depth > 4 or wait time > SLA 15m) and provides 1-click counter activation and dynamic staff reallocation recommendations. |
| **5. Configurable Priority & Appointment Slots** | Predefined transparent rules: Emergency (2000 pts), Senior/Differently-Abled (800 pts), Scheduled Appointment (400 pts), General (100 pts), with aging bonus (+4 pts/min) to prevent queue starvation. |
| **6. Simulated Notifications System** | Citizen digital pass includes a real-time smartphone SMS notification center with status change alerts (*"Your turn is approaching"*, *"Now Serving"*, *"Wait time updated"*). |
| **7. Staff Counter Terminal** | Counter operators can call next token (priority-weighted FIFO), complete consultations, and record no-shows with live service timer. |
| **8. Multi-Domain Presets** | Seamless 1-click switching between **Hospital Healthcare**, **Smart Banking**, and **Jan Seva Kendra (Government Office)** with pre-seeded sample data. |

---

## 🌟 Interactive "Dhaasu" Features & Pitch Boosters

1. **⚡ Fast-Forward My Turn (Live Pitch Button)**:
   - On the Citizen Pass view, click **"Fast-Forward My Turn"** to instantly advance your token across the entire lifecycle: *In Queue (Waiting) ➔ Approaching (Alert Sent!) ➔ Now Serving (Audio Chime & Window Callout!) ➔ Completed*.
   - Allows presenting the entire citizen experience in under 15 seconds without waiting!

2. **🔊 Web Audio Synthesizer Chimes & Voice Callouts (100% Offline)**:
   - Generates an airport/hospital chime (*Ding-Dong*) using JavaScript `AudioContext` harmonics, followed by dynamic voice synthesis: *"Token OPD-102, please proceed to Counter 2"*.

3. **🔥 Instant Rush-Hour Surge Simulator**:
   - In 1 click, flood the queue with 5 surge walk-ins to immediately trigger the **AI Overcrowding Engine** and show judges how the AI detects bottlenecks in real-time.

4. **⚡ 1-Click AI Auto-Rebalancing**:
   - The AI continuously calculates arrival velocity $\lambda$ and handling time $\mu$. When queues breach SLA targets (> 15m), click **"Apply AI Recommendation"** to auto-activate backup windows or reassign staff!

5. **📱 Smartphone Push & SMS Simulator**:
   - Visual mobile chat bubble feed showing alerts: *"🔔 Ping: 2 people ahead of you! Your turn is approaching."*

6. **📊 Dual Real-time Dynamic Charts (Chart.js)**:
   - **Chart 1:** Bar chart comparing waiting citizens vs currently attended across departments.
   - **Chart 2:** Line chart with gradient fill tracking hourly arrival curves and wait time trends.

7. **🔄 Department-to-Department Transfer Desk**:
   - Staff can easily transfer a patient/citizen from Consultation to Diagnostics/X-Ray or Pharmacy with transfer notes.

---

## 🏗️ System Architecture

```mermaid
graph TD
    User([Citizen / Patient]) -->|Kiosk / Mobile| API_Token[Token Generation Endpoint]
    Staff([Counter Staff]) -->|Call / Complete| API_Counter[Counter Action Endpoint]
    Admin([Administrator]) -->|Reallocate / Toggle| API_Admin[Admin & AI Management]

    subgraph Backend_Engine [QueueSmart Core Engine]
        API_Token --> Engine[QueueSmartEngine]
        API_Counter --> Engine
        API_Admin --> Engine

        Engine --> Priority[Priority Scoring Engine\nBase Weight + Aging Bonus]
        Engine --> WaitCalc[Algorithmic Wait-Time Forecaster]
        Engine --> AIEngine[AI Bottleneck & Surge Analyzer]
        Engine --> NotifEngine[Simulated SMS Push Dispatcher]
    end

    subgraph Frontend_Views [Responsive Web Application]
        Engine --> View1[📱 Citizen Kiosk & Boarding Pass]
        Engine --> View2[🖥️ Public Live TV Status Board]
        Engine --> View3[👨‍💼 Staff Service Counter Terminal]
        Engine --> View4[🧠 AI Optimization & Analytics Dashboard]
    end
```

---

## 🧮 Mathematical Transparency & Formulas

### 1. Transparent Priority Score
$$\text{Score} = \text{BaseWeight} + (\text{MinutesWaiting} \times 4.0)$$
- **Emergency / Triage:** 2000 pts
- **Senior (60+) / Differently Abled / Expectant:** 800 pts
- **Scheduled Appointment:** 400 pts
- **General Walk-in:** 100 pts
*The aging bonus prevents starvation of standard general walk-in citizens even during priority influx.*

### 2. Algorithmic Wait Time Forecast
$$\text{Estimated Wait Time} = \left\lceil \frac{\text{Position Ahead} \times \text{Average Handling Time}}{\text{Active Open Counters}} \right\rceil$$

---

## 🚀 How to Run the Application

The web server is running locally on:
👉 **[http://127.0.0.1:5000](http://127.0.0.1:5000)**

### Quick Verification & Automated Tests
To run the automated integration test suite:
```powershell
python test_app.py
```

---

## 🎯 Hackathon Presentation Script (Pitch Outline)

1. **The Hook (30s):**
   *"Judges, long queues at hospitals, banks, and government offices waste hours of productive citizen time and overwhelm service staff. QueueSmart AI turns unpredictable waiting into a transparent, stress-free digital experience."*

2. **Citizen Experience Demo (1m):**
   - Show how a citizen registers for a service (e.g. Senior Citizen or General).
   - Point out the instant **Digital Boarding Pass** with live countdown and transparent calculation formula.
   - Show the **Simulated SMS Inbox** alerting the citizen when their turn is approaching!

3. **Public TV Display Board & Voice Callout (45s):**
   - Switch to the **Live Display Board** tab.
   - Show the glowing "Now Serving" counter cards and audio callout announcement.

4. **Staff Terminal & AI Optimization Center (1m):**
   - Click "Call Next Citizen" from the Staff Counter tab.
   - Switch to the **AI Optimization & Admin** tab to show the real-time bottleneck detection alert and demonstrate the **1-click "Apply AI Recommendation"** button dynamically balancing the counters!
