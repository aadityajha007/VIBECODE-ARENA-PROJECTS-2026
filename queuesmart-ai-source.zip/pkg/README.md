# QueueSmart AI

Single-file local prototype. Open `index.html` in a browser; no install, backend, API keys or build step needed.

- Data is saved in the browser's localStorage only (no multi-device sync).
- Waiting-time estimates and Smart Insights are simple rule-based calculations, not machine learning.
- Notifications are simulated inside the app (no SMS, WhatsApp or push).
